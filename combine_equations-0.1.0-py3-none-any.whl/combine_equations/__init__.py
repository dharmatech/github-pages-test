# Desktop GUI (requires tkinter)
# from combine_equations.equation_gui import show_equation_gui

# Jupyter GUI (requires ipywidgets)
from combine_equations.equation_gui_jupyter import show_equation_gui_jupyter

# def main() -> None:
#     print("Hello from combine-equations!")
