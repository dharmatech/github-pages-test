from combine_equations.equation_gui import show_equation_gui

def main() -> None:
    print("Hello from combine-equations!")
